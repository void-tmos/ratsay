run("cp /tmp/ratsay/ratsay.py /py/ratsay.py")
